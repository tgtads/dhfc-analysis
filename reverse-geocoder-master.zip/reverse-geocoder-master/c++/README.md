# A simple c++ wrapper
## Building

    cmake PATH/TO/reverse_gecoder/c++
    make
    
## Running

    ./main 44.836383 -0.575720
